

extern unsigned long fark[];

extern volatile signed char digit;
extern volatile unsigned char dig_fark;

void topla(unsigned char *kaynak, unsigned char uzunluk, unsigned char ascii);
void cevir(unsigned long veri, unsigned char *hedef, unsigned char uzunluk,unsigned char ascii);
void pcevir(unsigned long veri, unsigned char *hedef, unsigned char uzunluk,unsigned char nokta);