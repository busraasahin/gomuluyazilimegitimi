
const unsigned char LCD_mesajlari[6][21]=
{
    "                    ",
    "                    ",
    "  PORTE ELEKTRONIK  ",
    "  www.porte.com.tr  ",
    " PROFESYONEL GOMULU ",
    " YAZILIM GELISTIRME "    
};