extern unsigned char tx_buffer[20];
extern unsigned char tx_indis;
extern unsigned char gidecek_veri; 

extern unsigned char rx_buffer[20];
extern unsigned char rx_indis;
extern unsigned char paket_geldi;

extern unsigned char com1_timeout;

void receive (void);
void send (void);
void haberles (void);


